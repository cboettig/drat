
#' Return a reference to a given table in the taxadb database
#'
#' @param db a connection to the taxadb database. Default will
#' attempt to connect automatically.
#' @param schema the table schema on which we want to run the query
#' @importFrom dplyr tbl
#' @inheritParams filter_by
#' @export
taxa_tbl <- function(
  provider = c("itis", "ncbi", "col", "tpl",
               "gbif", "fb", "slb", "wd", "ott",
               "iucn"),
  schema = c("dwc","common"),
  db = td_connect()){

  provider <- match.arg(provider)
  schema <- match.arg(schema)
  tbl_name <- paste0(schema, "_", provider)

  if (is.null(db)){
    mem_quick_db <-
      memoise::memoise(quick_db,
                       cache = memoise::cache_filesystem(taxadb_dir()))
    return(mem_quick_db(tbl_name))
  }
  if (!has_table(tbl_name, db)){
    td_create(provider = provider, schema = schema, db = db)
  }
  dplyr::tbl(db, tbl_name)
}
## could memoise to disk, but for some reason quickdb is not memoising...


has_table <- function(table = NULL, db = td_connect()){
  if (is.null(db)) return(FALSE)
  else if (table %in% DBI::dbListTables(db)) return(TRUE)
  else FALSE
}

#' @importFrom memoise memoise cache_filesystem
#' @importFrom readr read_tsv
quick_db <-
  function(tbl_name){
    #tmp <- tempfile(fileext = ".tsv.bz2")
    tmp <- file.path(taxadb_dir(), paste0(tbl_name, ".tsv.bz2"))
    if(!file.exists(tmp)){
      download.file(paste0(providers_download_url(tbl_name), ".tsv.bz2"),
             tmp)
    }
    suppressWarnings(
      readr::read_tsv(tmp,
      col_types = readr::cols(.default = readr::col_character()))
    )
  }


## Memoized on install, so any cache location must already exist.


# tibble doesn't like null arguments
#' @importFrom tibble lst tibble
null_tibble <- function(...){
  call <- Filter(Negate(is.null), tibble::lst(...))
  do.call(tibble::tibble, call)
}
