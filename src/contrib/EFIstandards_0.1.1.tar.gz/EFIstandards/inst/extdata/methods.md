# Methods Description

**Forecast timestep**
1 day

**Forecast time horizon**

**Data assimilation**

Data Assimilation used: No
If, DA used - type of method: N/A
If, DA used - Number of parameters calibrated: N/A
If, DA used - Sources of training data (DOI, GitHub): N/A

**Model Description**

Type of model (Empirical, process-based, machine learning): Empirical
Model name: discrete Lotka–Volterra model
Location of repository with model code: https://github.com/somewhere or https://doi.org/10.xxx
Model citation: N/A
Total number of model process parameters: 3

**Model Covariates**

Type (i.e., meteorology): N/A
Source (i.e., NOAA GEFS): N/A

**Uncertainty**

Answers: No, Derived from data, Propagates, Assimilates

Initial conditions:
Parameter:
Parameter Random Effects:
Process (within model):
Multi-model:
Driver:
Scenario:

Method for propagating uncertainty (Analytic, ensemble numeric): ensemble numeric
If Analytic, specific method
If ensemble numeric, number of ensembles: 10



