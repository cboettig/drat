#ifdef HAVE_EMBEDDED_R
#include <R.h>

extern SEXP mapi_split(SEXP mapiLinesVector, SEXP numCols);

#endif
