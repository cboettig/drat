void mapi_unescape(char* in, char* out);
void mapi_line_split(char* line, char** out, size_t ncols);
