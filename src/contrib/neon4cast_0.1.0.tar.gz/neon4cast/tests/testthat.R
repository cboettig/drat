library(testthat)
library(neon4cast)

test_check("neon4cast")
